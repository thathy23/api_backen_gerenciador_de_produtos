package br.com.gerenciadordeprodutos.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorDeProdutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
